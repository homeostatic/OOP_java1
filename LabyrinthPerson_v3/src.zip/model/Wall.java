package model;

public class Wall extends Block{

    public Wall(){
        this.passable = false;
    }
    
}


