package model;

public abstract class Block {
    boolean passable;

    public boolean isPassable() {
        return passable;
    }

    

    
}
