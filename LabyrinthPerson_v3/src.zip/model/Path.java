package model;

public class Path extends Block {
    public Path(){
        this.passable = true;
    }
}
